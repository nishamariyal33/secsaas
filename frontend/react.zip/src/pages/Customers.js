import { useEffect, useState, useContext } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import AddCustomer from '../components/AddCustomer';
import { baseUrl } from '../shared';
import { LoginContext } from '../App';
import useFetch from '../hooks/UseFetch';

export default function Customers() {
    const [loggedIn, setLoggedIn] = useContext(LoginContext);
    // const [customers, setCustomers] = useState();
    const [show, setShow] = useState(false);

    function toggleShow() {
        setShow(!show);
    }

    const location = useLocation();
    const navigate = useNavigate();

    const url = baseUrl + 'api/customers/';
    const {
        request,
        appendData,
        data: { customers } = {},
        errorStatus,
    } = useFetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Authorization: localStorage.getItem('access'),
        },
    });

    useEffect(() => {
        request();
    }, []);

    //useEffect(() => {
    //    console.log(request, appendData, customers, errorStatus);
    //});

    function handleClick(scan_id){
        console.log('wwwww ',scan_id)
        fetch(`http://localhost:4000/scan/getScanResult`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'responseType':'blob',
                Authorization: localStorage.getItem('access'),
                
            },
            body:JSON.stringify({scan_id,file_format:"pdf"})
        })
        .then(async(res) => {
            console.log("wwwwww ",res);
            let response=await res.json()
            console.log("xxxxx ",response);
            const url = window.URL.createObjectURL(new Blob([response.data]));
          const link = document.createElement('a');
          link.href = url;
          if (typeof window.navigator.msSaveBlob === 'function') {
              window.navigator.msSaveBlob(
                  response.data,
                  "result.pdf"
              );
          } else {
              link.setAttribute('download', "result.pdf");
              document.body.appendChild(link);
              link.click();
          }  
        }).catch((error)=>{
            console.log("errorrrr ",error);
        })
       
    
       };

    function newScan(targetUrl, scanType) {
        appendData({ targetUrl: targetUrl, scanType: scanType });

        if (!errorStatus) {
            toggleShow();
        }
    }

    return (
        <>
         <AddCustomer
                newScan={newScan}
                show={show}
                toggleShow={toggleShow}
            />
            <h1>Here are list of scans created:</h1>
            {customers
                ? customers.map((customer) => {
                      return (
                          <div className="m-2" key={customer.id}>
                              {/* <Link to={'/customers/' + customer.id}> */}
                                  <button className="no-underline bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded" onClick={handleClick.bind(this,customer.id)}>
                                     Scan target: {customer.requested_targets[0].target} State: {customer.state} 
                                  </button>
                              {/* </Link> */}
                          </div>
                      );
                  })
                : null}

           
        </>
    );
}
