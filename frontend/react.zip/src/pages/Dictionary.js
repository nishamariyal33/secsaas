import DefinitionSearch from '../components/DefinitionSearch';

export default function Dictionary() {
    return (
        <div className="flex justify-center">
            <DefinitionSearch />
        </div>
    );
}
