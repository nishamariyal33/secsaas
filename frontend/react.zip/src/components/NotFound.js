export default function NotFound() {
    return <p>The page you are looking for was not found</p>;
}
